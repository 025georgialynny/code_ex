#include "Player.h"
#include <cstdlib>
#include <ctime>
template <class AreaType>
class myPlayer : public Player<AreaType>
{
public:
  myPlayer(){
    Player<AreaType>::maxHP = 100;
    Player<AreaType>::maxSP = 100;
    maxThirst = 0;
    maxHunger = 0;
    maxTime = 120;
    start = 0;
    resetPlayer();
  }
  void randomi(int num){
    rando = rand()%num+1;
    if(rando<=round){
      rando+=round;
    }
  }
  void resetPlayer(){
    thirst = maxThirst;
    time = maxTime;
    hunger = maxHunger;
    round = start;
    randomi(10);
    Player<AreaType>::hp = Player<AreaType>::maxHP;
    Player<AreaType>::sp = Player<AreaType>::maxSP;
    Player<AreaType>::items.initializeList();//delete all items in list
  }
  void rounds(){//effects time thirst an hunger, if you get a random number then you lose more
    if(round == rando){
        cout<<"You spend too long in the last room!"<<endl;
        time -= 30;
        hunger += 15;
        thirst += 20;
        randomi(round+10);
        reportStats();
    }
    else{
      time -= 10;
      thirst += 10;
      hunger += 5;
    }
    round++;
  }
  void reportStats(){
    cout<<"Thirst Level: "<<thirst<<"%"<<endl;
    cout<<"Hunger Level: "<<hunger<<"%"<<endl;
    cout<<"Time: "<<time<<" minutes"<<endl;
    cout<<"Hit Points: "<<Player<AreaType>::hp<<endl;
    cout<<"Sanity Points: "<<Player<AreaType>::sp<<endl;
  }

	int isGameOver(){
     //rounds();
    if(thirst >= 100 || hunger >= 100
        || time <= 0 || Player<AreaType>::sp <= 0
        || Player<AreaType>::hp <= 0) {
          if(thirst>=100){
            cout<<"Your thirst overcame you! - you died."<<endl;
          }
          else if (hunger>=100) cout<<"Your hunger overcame you! - you died."<<endl;
          else if (time<=0) cout<<"You ran out of time! - you died."<<endl;
          else if (Player<AreaType>::sp<=0) cout<<"You lost your sanity! - you died."<<endl;
          else cout<<"You sustained too many injuries! - you died."<<endl;
        }
    else if(Player<AreaType>::currentLocation->info.getGoal()){
      Player<AreaType>::currentLocation->info.displayArea();
      return 1;
    }
    else if (Player<AreaType>::currentLocation->info.getID()){
      Player<AreaType>::currentLocation->info.displayArea();
      return 2;
    }

    else {return 0; }
  }
  //uLList<Item*> items;
  private:/*
protected: from player.h class
  int hp; //health points
  int sp; //sanity points
  int maxHP;
  int maxSP;
  areaNode<AreaType>* currentLocation;
  */
  int thirst, maxThirst;
  int hunger, maxHunger;
  int time, maxTime;
  int round, start, rando;

};
