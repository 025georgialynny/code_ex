#ifndef ullItem
#define ullItem
	#include "ull.h"
	#include "Item.h"
#endif

template <class AreaType>
class Player{
  public:
    uLList<Item*> items;

    virtual void resetPlayer() = 0;

    virtual void reportStats() = 0;

		void setCurrent(areaNode<AreaType>* loc){
			currentLocation = loc;
		}

		areaNode<AreaType>* getCurrent(){
			return currentLocation;
		}

		void inventory(){
			if(items.isEmptyList()){
				cout<<"\tYou have no items in your inventory."<<endl;
				return;
			}
			nodeType<Item*> *h;
			h = items.getFirst();
			cout<<"You have the following items: "<<endl;
			while(h != NULL){//uses pointer to first item in ull to print each name of item in list
				cout<<"\t"<<h->info->getName()<<endl;
				h = h->link;
			}
		}
		void take(){
			string takeIt;
			nodeType<Item*> *roomstuff;
			roomstuff = currentLocation->info.items.getFirst();
			if(roomstuff==NULL){
				cout<<"There is nothing in this room"<<endl;
				return;
			}
			else{
				cout<<"Take what item?"<<endl;
				getline(cin, takeIt);
				while(roomstuff != NULL){
					if(roomstuff->info->getName() == takeIt){//uses a pointer to first item in ull to find and move item
						items.insertLast(roomstuff -> info);
						cout<<"You have taken: "<<roomstuff->info->getName()<<endl;
						currentLocation->info.items.deleteNode(roomstuff->info);
						return;
					}
					roomstuff = roomstuff->link;
				}
				cout<<"Item is not in room!"<<endl;
			//Your code here: Phase 2
		}
	}

		void leave(){
			string leaveit;
			nodeType<Item*> *personstuff;
			personstuff = items.getFirst();
			if(personstuff==NULL){
				cout<<"There is nothing in your inventory"<<endl;
				return;
			}
			else{
				cout<<"Leave which item?"<<endl;
				getline(cin, leaveit);
				while(personstuff!=NULL){//uses a pointer to first item in ull to find and move item
					if(personstuff->info->getName() == leaveit){
						currentLocation->info.items.insertLast(personstuff->info);
						cout<<"You have Dropped: "<<personstuff->info->getName()<<endl;
						items.deleteNode(personstuff->info);
						return;
					}
					personstuff = personstuff ->link;
				}
				cout<<"Item is not in your inventory!"<<endl;
			}
			//Your code here: Phase 2
		}
		void examine(){
			string examineit;
			nodeType<Item*> *stuff;
			stuff = items.getFirst();
			if(stuff == NULL){
				cout<<"There is nothing in your inventory"<<endl;
				return;
			}
			else{
				cout<<"Examine which item?"<<endl;
				getline(cin, examineit);
				while(stuff!=NULL){//uses a pointer to first item in ull to find to examine
					if(stuff->info->getName() == examineit){
						stuff->info->displayDesc();
						return;
					}
					stuff = stuff->link;
				}
			}
			cout<<"Item is not in your inventory!"<<endl;
			//Your code here: Phase 2
		}

		//isGameOver should return: 0 for continue, 1 for win, 2 for lose
		virtual int isGameOver() = 0;

  protected:
    int hp; //health points
		int sp; //sanity points
		int maxHP;
		int maxSP;
		areaNode<AreaType>* currentLocation;

};
