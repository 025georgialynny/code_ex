#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdlib.h>

#ifndef ullItem
#define ullItem
	#include "ull.h"
	#include "Item.h"
#endif

using namespace std;

template <class AreaType>
struct areaNode
{
	AreaType info;
	areaNode<AreaType> *u;
	areaNode<AreaType> *d;
	areaNode<AreaType> *l;
	areaNode<AreaType> *r;
};

template <class AreaType>
class Map{
	private:
		vector<areaNode<AreaType>*> areasVec;
		int areacnt;

	public:
		Map(){
			areacnt = 0;
			Item *stuff;
			int room;
			string gF;
			string nextLine;
			string description;
			string token;
			char c;
			int linecount = 1, id, g;
			int u, d, l, r;
			int count=0;

			cout<<"Enter your gamefile name (i.e. filename.txt)"<<endl;
	   	cin>>gF;
	   	//gF = "DragonCrawl_v2.txt";
	   	ifstream inFile;
	   	inFile.open(gF.c_str());

			//throw away any text before #areas
			while(nextLine != "#areas"){
				getline(inFile, nextLine);
				//cout<<nextLine<<endl;
			}

			//process all the areas
			while(nextLine != "#links"){
				//cout<<nextLine<<endl;
				c=inFile.peek();
				getline(inFile, nextLine);
				if(c!='%' && nextLine != "" && nextLine != "#links"){
					if(linecount == 1){//first line is description
						AreaType* tempRmPtr = new AreaType;
						areaNode<AreaType>* tempNodePtr = new areaNode<AreaType>;
          	tempNodePtr->info = *tempRmPtr;
						//Add tempNodePtr to vector here
						areasVec.push_back(tempNodePtr);

						description = nextLine;
          	linecount = 2;
		   			areasVec[areacnt]->info.setDescription(description);
            //cout<<areasVec[areacnt]->info.getDescription()<<endl;
          }//if
          else if(linecount == 2){//parse second line to get modifiers and booleans
	   	   		istringstream ss(nextLine);
           	getline(ss, token, ',');
           	id = atoi(token.c_str());
						areasVec[areacnt]->info.setID(id);

           	getline(ss, token, ',');
           	g = atoi(token.c_str());
						areasVec[areacnt]->info.setGoal(g);

	   	   		//cout<<areasVec[areacnt]->info.getID()<<":"<<areasVec[areacnt]->info.getGoal()<<endl;
   	   	    linecount = 1;
	          areacnt++;
	        }//else if
				}//if
			}//while


			while(nextLine != "#items"){
				//cout<<nextLine<<endl;
				c=inFile.peek();
				getline(inFile, nextLine);
				if(c!='%' && nextLine != "" && c!='#'){
					//cout<<nextLine<<endl;
					count++;  //keep track of what area we're linking up
					istringstream ss(nextLine);
        	getline(ss, token, ',');
        	u = atoi(token.c_str());
        	getline(ss, token, ',');
        	d = atoi(token.c_str());
					getline(ss, token, ',');
        	l = atoi(token.c_str());
					getline(ss, token, ',');
					r = atoi(token.c_str());
					//cout<<u<<":"<<d<<":"<<l<<":"<<r<<endl;

					areasVec[count-1]->u = areasVec[u-1];
					areasVec[count-1]->d = areasVec[d-1];
					areasVec[count-1]->l = areasVec[l-1];
					areasVec[count-1]->r = areasVec[r-1];
				}
			}
			if(areacnt != count){
				cout<<"WARNING: the number of lines of area links is NOT the same as the number of areas. The leftover areas are not linked (leaving) to other areas."<<endl;
			}

			linecount = 1;
			while(getline(inFile, nextLine)){//sets each item listed to its room using a dynamically allocated Item type variable
				if(nextLine[0]!='%' && nextLine != "" && nextLine[0]!='#'){
							if (linecount == 1){
								stuff = NULL;
								stuff = new Item;
								stuff->setName(nextLine);
								linecount = 2;
							}
							else if (linecount == 2){
								stuff->setDesc(nextLine);
								linecount = 3;
							}
							else if (linecount == 3){
								room = stoi(nextLine)-1;
								stuff->setSR(room);
								linecount = 1;
								if(room>areacnt){
									cout<<"Room for "<<stuff->getDesc()<<" is not in range."<<endl;
								}
								else{
									areasVec[room]->info.items.insertFirst(stuff);
								}
							}
				}
			}



		}//constructor


		areaNode<AreaType>* getStart(){
			return areasVec[0];  //returns a pointer to the first area listed
		}
		void returnItems(nodeType<Item*> *stuff){//used in game to reset items back to original position
			int p;
			nodeType<Item*> *rooms;
			while (stuff!=NULL){//stuff points to first item in players inventory to return those items
				p = stuff -> info->getSR();
				areasVec[p]->info.items.insertLast(stuff->info);
				stuff = stuff->link;
			}
			for(int i = 0; i<areasVec.size(); i++){//this loop runs through items in each rooms inventory to return them to the correct room
				rooms = areasVec[i]->info.items.getFirst();
				while(rooms!=NULL){
					if(rooms->info->getSR()!=i){
						areasVec[rooms->info->getSR()]->info.items.insertLast(rooms->info);
						areasVec[i]->info.items.deleteNode(rooms->info);
					}
					rooms = rooms->link;
				}
			}
		}
		void print(){
			cout<<"******************************************************************"<<endl;
			cout<<"CHEATING!!!! Printing the set of areas and connections on the map."<<endl;
			cout<<"******************************************************************"<<endl;
			for(int i=0; i<areasVec.size(); i++){
				cout<<"This is area: "<<i+1<<endl;
				cout<<areasVec[i]->info.getDescription()<<endl;
				if(areasVec[i]->info.getID() == 1){
					cout<<"Area is INSTADEATH."<<endl;
				}
				if(areasVec[i]->info.getGoal() == 1){
					cout<<"Area is GOAL."<<endl;
				}
				cout<<"Connections:"<<endl;
				cout<<"\t u: Area #"<<reverseLookUp(areasVec[i]->u)<<endl;
				cout<<"\t d: Area #"<<reverseLookUp(areasVec[i]->d)<<endl;
				cout<<"\t l: Area #"<<reverseLookUp(areasVec[i]->l)<<endl;
				cout<<"\t r: Area #"<<reverseLookUp(areasVec[i]->r)<<endl;
				/*cout<<"Items"<<endl;
				nodeType<Item*> *stuff;
				stuff = areasVec[i]->info.items.getFirst();
				while(stuff!=NULL){
					stuff->info->displayName();
					stuff = stuff->link;
				}*/
			}
		}

		int reverseLookUp(areaNode<AreaType>* addy){
			for(int i=0; i<areasVec.size(); i++){
				if(areasVec[i] == addy){
					return i+1;
				}
			}
		}
};
