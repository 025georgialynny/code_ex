#include "Area.h"
#include "Map.h"
#include "myPlayer.h"

#ifndef ullItem
#define ullItem
	#include "ull.h"
	#include "Item.h"
#endif


template <class AreaType, class PlayerType>
class Game{
	private:
		PlayerType player1;
		Map<AreaType> map;

  public:
		Game(){
			player1.setCurrent(map.getStart());
		}

  	void play(){
	  	string userInput;
			cin.ignore();
			areaNode<AreaType> *current;
      while(player1.isGameOver()==0)/*do*/{
				//check game status

      	//display area data
				//player1.reportStats();
	    	player1.getCurrent()->info.displayArea();

	  		//get movement selection
	  		cout<<"Which way would you like to go?  Enter u, d, l, or r"<<endl;
				getline(cin, userInput);

	  		//update area
	  		if(userInput == "u"){
       		player1.setCurrent(player1.getCurrent()->u);
		 		}
				else if(userInput == "d"){
					player1.setCurrent(player1.getCurrent()->d);
				}
				else if(userInput == "l"){
					player1.setCurrent(player1.getCurrent()->l);
				}
				else if(userInput == "r"){
	  			player1.setCurrent(player1.getCurrent()->r);
				}
				else if(userInput == "iseedeadpeople"){ //issdeadpeople cheat code to reveal map
					map.print();
				}
				else if(userInput == "reset"){
					//May need to be updated
					player1.setCurrent(map.getStart());//puts player at start
					map.returnItems(player1.items.getFirst());//returns items from players inventory and puts all left items back in original room
					player1.resetPlayer();//resets player and stats while deleting items from its inventory

				}
				else if(userInput == "exit"){
					cout<<"Good bye!"<<endl;
					return;
				}
				else if(userInput == "help"){//lists help commands
					cout<<"Commands: "<<endl;
					cout<<"\tu - go up"<<endl;
					cout<<"\td - go down"<<endl;
					cout<<"\tl - go left"<<endl;
					cout<<"\tr - go right"<<endl;
					cout<<"\thelp - list commands"<<endl;
					cout<<"\tsearch - list items in room"<<endl;
					cout<<"\tinventory - list items you have"<<endl;
					cout<<"\ttake - take item in room"<<endl;
					cout<<"\tleave - discard something in your inventory"<<endl;
					cout<<"\texamine - examine something in your inventory"<<endl;
					cout<<"\tiseedeadpeople - CHEAT CHEAT - see map"<<endl;
					cout<<"\treset - reset the game"<<endl;
					cout<<"\texit - exit the game"<<endl;
				}
				else if (userInput == "search"){
					player1.getCurrent()->info.search();//searches current room
				}
				else if (userInput == "inventory"){
					player1.inventory();//displays player inventory
				}
				else if (userInput == "take"){
					player1.take();//takes something from current room
				}
				else if (userInput == "leave"){
					player1.leave();//leaves something from inventory in current room
				}
				else if (userInput == "examine"){
					player1.examine();//examine something in current room
				}
				//Additional Code here
				else{
					cout<<"I do not understand: "<<userInput<<endl<<endl;
				}


			}//while(player1.isGameOver()==0);
    }//play()

};
