#include <string>
#include <iostream>
#ifndef ullItem
#define ullItem
	#include "ull.h"
	#include "Item.h"
#endif

using namespace std;

class Area{
  public:
		uLList<Item*> items;

    void setDescription (string desc){
    	description = desc;
    }
		void setGoal(bool g){
			goal = g;
		}
		void setID(bool id){
			instadeath = id;
		}
    string getDescription(){
    	return description;
    }
    bool getID(){
    	return instadeath;
    }
		bool getGoal(){
			return goal;
		}
		void displayArea(){
			cout<<description<<endl;
		}
		void search(){
			nodeType<Item*> *stuff;
			//your code here: Phase 2
			if(items.isEmptyList()){
				cout<<"There is nothing in this room"<<endl;
			}
			else{
				cout<<"The following items are in this room:"<<endl;
				stuff = items.getFirst();//uses pointer to areas items to display items in room
				while(stuff!=NULL){
					cout<<"\t"<<stuff->info->getName()<<endl;
					stuff = stuff->link;
				}
			}
		}

  private:
    string description;
		bool instadeath;
		bool goal;

};
