//Georgia Smith CSC 2180-2 PA 5

#include <iostream>
using namespace std;
#include <string>
#include <cctype>
#include "node.h"//multiple declarations of nodeType screwed stuff up so i threw it in a .h
#include "linkedQueue.h"
#include "derivedLinkedStack.h"

void wq(const string w, linkedQueueType<char>& queue){//a function that converts the word into a queue
  int len = w.size();
  char lc;
  for(int i = 0; i<len; i++){
    if(w[i]!=' '){
      lc=tolower(w[i]);
      queue.addQueue(lc);
    }
  }
}
void ws(const string w, linkedStackType<char>& stack){//a function that converts the word into a stack
  int len = w.size();
  char lc;
  for(int i = 0; i<len; i++){
    if(w[i]!=' '){
      lc=tolower(w[i]);
      stack.push(lc);
    }
  }
}
bool isPal(linkedQueueType<char>& queue, linkedStackType<char>& stack){//a function that returns true/false depending on if the word is a palindrome
    while(queue.front() == stack.top()){
      queue.deleteQueue();
      stack.pop();
      if(queue.isEmptyQueue()) break;//if either is empty end the loop
      else if(stack.isEmptyStack()) break;
    }
    if(queue.isEmptyQueue() && stack.isEmptyStack()){//only returns true if both data structures are empty (ie if one empties before the otherwise
                                                            //or the loop ended early because the corresponding entries were not the same
      return true;
    }
    else{
      return false;
    }
}

int main(){
  string word;
  linkedQueueType<char> wordq;
  linkedStackType<char> wordst;
  cout<<"Enter a word/phrase and I'll see if it is a palindrome!"<<endl;
  getline(cin, word);
  wq(word, wordq);
  ws(word, wordst);
  if(isPal(wordq, wordst)) cout<<"\""<<word<<"\" "<<"IS a palindrome!"<<endl;
  else cout<<"\""<<word<<"\" "<<"IS NOT a palindrome."<<endl;


}
