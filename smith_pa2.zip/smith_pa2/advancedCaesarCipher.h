 #include "caesarCipher.h"

class advancedCaesar : public caesarCipher
{

private:
  char ciph[26];
public:
  advancedCaesar(int shift) : caesarCipher(shift){
    ciph[0]=97 + (shift%26);
    for(int i = 1; i<26; i++){
      if(ciph[i-1]+1<=122){
        ciph[i]=ciph[i-1]+1;
      }
      else{
        ciph[i]= 97;
      }
    }
  }
  advancedCaesar() : caesarCipher(){
    ciph[0] = 98;
    for(int i = 1; i<26; i++){
      if(ciph[i-1]+1<=122){
        ciph[i]=ciph[i-1]+1;
      }
      else{
        ciph[i]= 97;
      }
    }
  }
  void print(){
    for(int i = 0; i<26; i++){
      cout<<ciph[i]<<" ";
    }

    cout<<endl<<"Shift value: ";
    caesarCipher::print();
    cout<<endl;
  }
};
