#include <iostream>
#include <string>
using namespace std;

#include "advancedCaesarCipher.h"

int main(){
  advancedCaesar aC1;
  advancedCaesar aC2(5);

  aC1.print();
  aC2.print();

  string acs = "hello";
  string encacs;

  encacs = aC1.encrypt(acs);
  cout<<acs<<">>"<<encacs<<endl;
  cout<<aC1.decrypt(encacs)<<endl;


  encacs = aC2.encrypt(acs);
  cout<<acs<<">>"<<encacs<<endl;
  cout<<aC2.decrypt(encacs)<<endl;






  return 0;
}
