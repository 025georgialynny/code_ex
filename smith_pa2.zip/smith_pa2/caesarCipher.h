

class caesarCipher {
protected:
		int shiftValue;

	public:
		//Default contructor - Will set shift value to 1.
		caesarCipher(){
			shiftValue = 1;
		}

		//Constructor to set shift value to specified number
		caesarCipher(int sv){
			shiftValue = sv;
		}

		//Returns the string encrypted using the assigned shift number.
		string encrypt(string s){
			for(int i=0;i<(s.length());i++){							//Go through each character in the string
				if (s[i] >= 97 && s[i] <= 122){			//Make sure the character is a-z
					if (s[i]+shiftValue > 122){
						s[i]=122-(s[i]%97);	//If shifting the character makes it go past Z, return it to A's end
					}
					else{
						s[i]+=shiftValue;											//Otherwise shift normally
					}
				}
			}
			return s;
		}

		//Returns a string that is decrypted using the supplied encrypted string and the shift value
		string decrypt(string s){
			for(int i=0;i<s.length();i++){							//Go through each character in the string
				if (s[i] >= 97 && s[i] <= 122){			//Make sure the character is a-z
					if (s[i]-shiftValue < 97){
						s[i]=97+(122%s[i]);	//If shifting the character makes it go below A, return it to Z's end
					}
					else{
						s[i]-=shiftValue;											//Otherwise shift normally
					}
				}
			}
			return s;
		}

		//Prints out the shift value
		void print(){
			cout << shiftValue << endl;
			return;
		}


};
